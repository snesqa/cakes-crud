<?php 
	$pageTitle = "Category";
    include 'includes/header.php';
    include 'includes/menu.php';
	require_once 'includes/conn.php';
?>
<body>

	<div class="wrapper">
		<div class="contact-wrapper">
			<table>
			<thead>
				<tr>
					<th colspan="2">Category</th>
				</tr>
			</thead>	

				<?php						
					$stmt = $link->prepare("SELECT cat_id, cat_type FROM category;");
					$stmt->execute();
					$stmt->bind_result($catid, $cattype);
					while($stmt->fetch()) {
					echo '<tr class="alt" >
					<td td colspan="2">'.$cattype.'</td>
					</tr>';
					}
				?>
			</table>
		</div>	
	<?php include 'includes/footer.php'; ?>
	</div><!--wrapper-->
</body>
</html>