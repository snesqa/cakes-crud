<footer>
	<div id="footer-info">Multimedia Design HOP Snezana Ilic &copy;20<?php echo date('y'); ?></div> 
    <!--http://php.net/manual/en/function.date.php
    	The date function automaticly keeps the year up to date at the bottom of the page.
    -->
</footer>