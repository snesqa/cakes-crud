
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title><?php echo $pageTitle; ?></title><!-- Here $pageTitle outputs or echos the page title declared and given a value on each site page  -->
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>