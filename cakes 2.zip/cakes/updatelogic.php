<?php
require_once 'includes/conn.php'; // establish db connection

$catid = filter_input(INPUT_POST, 'catid', FILTER_VALIDATE_INT) or die(' fejl her i catid');
$cattype = filter_input(INPUT_POST, 'cattype', FILTER_SANITIZE_STRING) or die('pname');


$sql = "UPDATE category SET cat_type=? where cat_id=?";

	$stmt = $link->prepare($sql); 
	$stmt->bind_param('si', $cattype, $catid);
	

	if($stmt->execute()){
		echo 'updated' ;
	}else{
		echo 'not working yet';
	}
	
	//echo 'inserted '.$pname.' as id:'.($stmt->insert_id); // id for inserted record
	//echo 'Your username is '.$email.' go to <a href="index.php">login</a>'
	//header("location: index.php?signup=true");
?>
<br>
<a href="update.php">Go back</a>