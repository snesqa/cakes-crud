<?php 
ob_start();
require_once 'includes/conn.php';


$projectdeleted;

$cid = filter_input(INPUT_POST, 'cid') or die(mysql_error());

$sql = "DELETE FROM category WHERE cat_id = $cid";
$stmt = $link->prepare($sql);
$stmt->bind_param('i',$cid);
$stmt->execute();
	 
//echo 'Project deleted , affected rows: '.$stmt->affected_rows ;
header('location:delete.php');
?>
