<?php 
	
    include 'includes/header.php';
	$pageTitle = "Create category";
    require_once('includes/header.php');
    require_once('includes/menu.php'); 
	require_once 'includes/conn.php';
	
?>
<body>
	<div class="wrapper">
		<div class="contact-wrapper">
		<h2>Create category</h2>
		<form action="createlogic.php" method="post">
			Category name* <br>
			<input type="text" name="cat_type"><br>
			<br>
			<input type="submit" value="Add new gategory">
		</form>

		<a href="index.php">Go back</a>

	</div>
</div>
	<?php //include 'includes/footer.php'; ?>
</div><!--wrapper-->
</body>
</html>
