<?php 
	$pageTitle = "Delete category";
    include 'includes/header.php';
    include 'includes/menu.php'; 
	require_once 'includes/conn.php';
?>
<body>
	<div class="wrapper">
		<div class="contact-wrapper">
	
	<h2>Delete Category</h2>
	<form action="deletelogic.php" method="post">
	<select name="cid">
		<option>Category name</option>

<?php

	$sql = "SELECT cat_id, cat_type FROM category";
	$stmt = $link->prepare($sql);
	$stmt->execute();
	$stmt->bind_result($cid, $cattype);
	while ($stmt->fetch()) {
		echo '	<option value="'.$cid.'">'.$cattype.'</option>'.PHP_EOL;
	}

	?>

</select><br>
	<input type="submit" value="Delete project">
</form>
</div>	
<?php include 'includes/footer.php'; ?>
</div><!--wrapper-->
</body>
</html>