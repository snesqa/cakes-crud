<?php

require_once 'includes/conn.php'; // establish db connection

$cattype = filter_input(INPUT_POST, 'cat_type') or die(' fejl i cat_type');


$sql = 'INSERT INTO category ( cat_type ) VALUES ( ? )';

	$stmt = $link->prepare($sql); 
	$stmt->bind_param('s', $cattype);
	$stmt->execute();

header('location:create.php')
;	//echo 'inserted resource name '.$cattype.' as id:'.($stmt->insert_id); // id for inserted record
	
?>
